﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UCT.Models
{
    public enum CompetencyType : byte
    {
        None = 0,
        LearningGoal = 1,
        Competency = 2,
        Descriptor = 3
    }
}